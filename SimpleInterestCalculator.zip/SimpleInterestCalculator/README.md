# Simple Interest Calculator

## Project Overview
The Simple Interest Calculator is a basic web application that calculates simple interest and the total amount using the principal amount, annual interest rate, and time period.

## Formula
**Simple Interest = (Principal × Rate × Time) / 100**

**Total Amount = Principal + Simple Interest**

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Features
- Accepts principal amount, annual interest rate, and time in years.
- Calculates simple interest.
- Calculates the total amount.
- Validates input values.
- Includes a reset button.
- Provides a simple, responsive interface.

## Example
- Principal Amount: 10000
- Annual Interest Rate: 5%
- Time: 2 years
- Simple Interest: 1000
- Total Amount: 11000

## How to Run
1. Download or clone this repository.
2. Open the project folder.
3. Open `index.html` in a web browser.
4. Enter the required values and click **Calculate Interest**.

## Purpose
This project demonstrates the simple interest formula and the use of HTML, CSS, and JavaScript to build an interactive web application.

## License
This project is available for educational purposes.
