const form = document.getElementById("interestForm");

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const principal = Number(document.getElementById("principal").value);
    const rate = Number(document.getElementById("rate").value);
    const time = Number(document.getElementById("time").value);

    if (
        !Number.isFinite(principal) ||
        !Number.isFinite(rate) ||
        !Number.isFinite(time) ||
        principal <= 0 ||
        rate < 0 ||
        time <= 0
    ) {
        alert("Enter a positive principal, a non-negative rate, and a positive time.");
        return;
    }

    // Simple Interest = (Principal × Rate × Time) / 100
    const simpleInterest = (principal * rate * time) / 100;

    // Total Amount = Principal + Simple Interest
    const totalAmount = principal + simpleInterest;

    document.getElementById("interest").textContent = simpleInterest.toFixed(2);
    document.getElementById("total").textContent = totalAmount.toFixed(2);
});

form.addEventListener("reset", function () {
    document.getElementById("interest").textContent = "0.00";
    document.getElementById("total").textContent = "0.00";
});
